using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebcamTagScanner
{
    public static class BingSearchService
    {
        public static async Task<List<string>> DiscoverWebcamSitesAsync(string apiKey)
        {
            // Search for popular webcam livestreaming sites
            var query = "popular webcam livestream sites";
            using var http = new HttpClient();
            http.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", apiKey);
            var url = $"https://api.bing.microsoft.com/v7.0/search?q={Uri.EscapeDataString(query)}";
            var resp = await http.GetAsync(url);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);

            var sites = new List<string>();
            if (doc.RootElement.TryGetProperty("webPages", out var webPages))
            {
                foreach (var v in webPages.GetProperty("value").EnumerateArray())
                {
                    var urlStr = v.GetProperty("url").GetString();
                    if (urlStr != null)
                    {
                        var host = new Uri(urlStr).Host;
                        // Only add unique hosts, and filter likely webcam domains
                        if (!sites.Contains(host) && (
                            host.Contains("chaturbate") || host.Contains("myfreecams") || host.Contains("bongacams") ||
                            host.Contains("camsoda") || host.Contains("stripchat") || host.Contains("livejasmin")))
                        {
                            sites.Add(host);
                        }
                    }
                }
            }
            // Always include demo sites
            var mustHave = new[] { "chaturbate.com", "myfreecams.com" };
            foreach (var s in mustHave)
                if (!sites.Contains(s)) sites.Add(s);

            return sites;
        }
    }
}