using System.Windows;

namespace WebcamTagScanner
{
    public partial class App : Application
    {
    }
}