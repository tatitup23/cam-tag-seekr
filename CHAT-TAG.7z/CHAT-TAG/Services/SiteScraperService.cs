using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AngleSharp;
using AngleSharp.Dom;

namespace WebcamTagScanner
{
    public static class SiteScraperService
    {
        public static async Task<List<string>> GetTagsForSiteAsync(string host)
        {
            if (host.Contains("chaturbate"))
                return await ScrapeChaturbateTagsAsync();
            if (host.Contains("myfreecams"))
                return await ScrapeMyFreeCamsTagsAsync();

            // For unknown sites, return empty for now
            return new List<string>();
        }

        // Demo for Chaturbate tag scraping
        static async Task<List<string>> ScrapeChaturbateTagsAsync()
        {
            var url = "https://chaturbate.com/tags/";
            var tags = new List<string>();
            var config = Configuration.Default.WithDefaultLoader();
            var context = BrowsingContext.New(config);
            var doc = await context.OpenAsync(url);
            var tagNodes = doc.QuerySelectorAll("a.tag");
            tags.AddRange(tagNodes.Select(t => t.TextContent.Trim()));
            return tags;
        }

        // Demo for MyFreeCams tag scraping (categories)
        static async Task<List<string>> ScrapeMyFreeCamsTagsAsync()
        {
            var url = "https://www.myfreecams.com/";
            var tags = new List<string>();
            var config = Configuration.Default.WithDefaultLoader();
            var context = BrowsingContext.New(config);
            var doc = await context.OpenAsync(url);
            // Categories are often in a sidebar or menu
            var tagNodes = doc.QuerySelectorAll(".category_list li, .categories-list li, .categories li");
            if (!tagNodes.Any())
                tagNodes = doc.QuerySelectorAll("a[href*='/category/']");
            tags.AddRange(tagNodes.Select(t => t.TextContent.Trim()).Where(t=>!string.IsNullOrWhiteSpace(t)));
            return tags;
        }
    }
}