{
"search_metadata":
{
"id":
"6892be506e22372dfb608490",
"status":
"Success",
"json_endpoint":
"https://serpapi.com/searches/e9f9c5a5278d527a/6892be506e22372dfb608490.json",
"pixel_position_endpoint":
"https://serpapi.com/searches/e9f9c5a5278d527a/6892be506e22372dfb608490.json_with_pixel_position",
"created_at":
"2025-08-06 02:30:40 UTC",
"processed_at":
"2025-08-06 02:30:40 UTC",
"google_url":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&oq=ADULT+WEBCAM+CATEGORY&uule=w+CAIQICINVW5pdGVkIFN0YXRlcw&hl=en&gl=us&safe=off&sourceid=chrome&ie=UTF-8",
"raw_html_file":
"https://serpapi.com/searches/e9f9c5a5278d527a/6892be506e22372dfb608490.html",
"total_time_taken":
2.05
},
"search_parameters":
{
"engine":
"google",
"q":
"ADULT WEBCAM CATEGORY",
"location_requested":
"United States",
"location_used":
"United States",
"google_domain":
"google.com",
"hl":
"en",
"gl":
"us",
"safe":
"off",
"device":
"desktop"
},
"search_information":
{
"query_displayed":
"ADULT WEBCAM CATEGORY",
"total_results":
523000000,
"time_taken_displayed":
0.25,
"organic_results_state":
"Results for exact spelling"
},
"organic_results":
[
{
"position":
1,
"title":
"Chaturbate - Free Adult Webcams, Live Sex, Free Sex Chat ...",
"link":
"https://chaturbate.com/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://chaturbate.com/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECBgQAQ",
"displayed_link":
"https://chaturbate.com",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5b0b01de8aae9914dfb347ad24e88ea97c.png",
"snippet":
"Watch Live Cams Now! No Registration Required - 100% Free Uncensored Adult Chat. Start chatting with amateurs, exhibitionists, pornstars w/ HD Video ...",
"snippet_highlighted_words":
[
"amateurs, exhibitionists, pornstars"
],
"source":
"Chaturbate"
},
{
"position":
2,
"title":
"Best Adult Cam Sites with Live Cam Girls of 2025",
"link":
"https://chicagoreader.com/adult/cam-sites/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://chicagoreader.com/adult/cam-sites/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECB0QAQ",
"displayed_link":
"https://chicagoreader.com › adult › cam-sites",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5b1e57e79a260f3a66827708153953c887.png",
"date":
"Jun 6, 2025",
"snippet":
"We've compiled a list of the best adult cam sites of 2025. From platforms renowned for their high-quality streaming and user-friendly interfaces to those ...",
"snippet_highlighted_words":
[
"best adult cam sites of 2025"
],
"source":
"Chicago Reader"
},
{
"position":
3,
"title":
"Category:Adult camming websites",
"link":
"https://en.wikipedia.org/wiki/Category:Adult_camming_websites",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://en.wikipedia.org/wiki/Category:Adult_camming_websites&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECBcQAQ",
"displayed_link":
"https://en.wikipedia.org › wiki › Category:Adult_camm...",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5be6fd402b5871a0ff7d6062b6f2179ac1.png",
"snippet":
"Pages in category "Adult camming websites" ; B · BongaCams ; C · Chaturbate ; L · LiveJasmin ; M · MyFreeCams ; S · Stripchat.",
"snippet_highlighted_words":
[
"Pages in category "Adult camming websites"
],
"source":
"Wikipedia"
},
{
"position":
4,
"title":
"Sites Like Chaturbate: 37 Cam Site Alternatives for All ...",
"link":
"https://www.villagevoice.com/the-best-sites-like-chaturbate-35-alternatives-from-freemium-to-premium/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.villagevoice.com/the-best-sites-like-chaturbate-35-alternatives-from-freemium-to-premium/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECBwQAQ",
"displayed_link":
"https://www.villagevoice.com › the-best-sites-like-chatu...",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5b591e559789203f7782d13656757f4d95.png",
"date":
"Jun 18, 2025",
"snippet":
"With intuitive search filters and category tags, users can easily discover new performers and explore different genres of adult entertainment.",
"snippet_highlighted_words":
[
"easily discover new performers"
],
"source":
"The Village Voice"
},
{
"position":
5,
"title":
"Stripchat: Free Live Sex Cams and Adult Chat with Naked Girls",
"link":
"https://stripchat.com/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://stripchat.com/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECBYQAQ",
"displayed_link":
"https://stripchat.com",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5bbfedefff302c9379e68a7b0124390a45.png",
"snippet":
"Watch Naked Models in our Adult Live Sex Cams Community. ❤️ It's FREE & No Registration Needed. 8000+ LIVE Cam Girls and Couples are Ready to Chat.",
"snippet_highlighted_words":
[
"Watch Naked Models in our Adult Live Sex Cams Community"
],
"source":
"Stripchat"
},
{
"position":
6,
"title":
"CamContacts: Sexy Web Cam Girls in Adult Chat Rooms",
"link":
"https://www.camcontacts.com/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.camcontacts.com/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECB8QAQ",
"displayed_link":
"https://www.camcontacts.com",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5babb0abc12a4e193f4a7d441134d88dfb.png",
"snippet":
"Welcome to the Best Adult Chat Webcam Community. Now it's your time to enjoy your cam girl's full attention. We have the friendliest web cam models online.",
"snippet_highlighted_words":
[
"Welcome to the Best Adult Chat Webcam Community"
],
"source":
"CamContacts"
},
{
"position":
7,
"title":
"ImLive.com: Cam Girls | Sex Cam Girls | See Webcam Girls",
"link":
"https://imlive.com/webcam-girls/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://imlive.com/webcam-girls/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECB4QAQ",
"displayed_link":
"https://imlive.com › webcam-girls",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5b8fc34a7bf05022ce22d7ee44e484f6ce.png",
"snippet":
"Looking for the hottest cam girl shows? Look no further because these kinky and insanely hot webcam girls are waiting for you to join their show.",
"snippet_highlighted_words":
[
"kinky and insanely hot webcam girls"
],
"source":
"ImLive.com"
},
{
"position":
8,
"title":
"Flirt4Free: Free Live Sex Cams and Sizzling Adult Chat",
"link":
"https://www.flirt4free.com/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.flirt4free.com/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECCwQAQ",
"displayed_link":
"https://www.flirt4free.com",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5b249d1ffcd548dc66036083fbb63f57af.png",
"snippet":
"Alternative 23 · Anal 111 · Arabian 1 · Asian 7 · BBW 16 · BDSM 17 · Big Boobs 105 · Big Butts 74 · Bisexual 16 · Blonde 38 · Bodybuilder 2 · Brunette 43 ...",
"snippet_highlighted_words":
[
"Alternative 23"
],
"source":
"Flirt4Free"
},
{
"position":
9,
"title":
"Omg Adult: Free Live Adult Webcams",
"link":
"https://omg.adult/",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://omg.adult/&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECDEQAQ",
"displayed_link":
"https://omg.adult",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5bd9ed2b1b7c07ebc549ffb4d6cac0e6ae.png",
"snippet":
"Watch Naked Models in our Adult Live Sex Cams Community. ❤️ It's FREE & No Registration Needed. 8000+ LIVE Cam Girls and Couples are Ready to Chat.",
"snippet_highlighted_words":
[
"Watch Naked Models in our Adult Live Sex Cams Community"
],
"source":
"Omg Adult"
},
{
"position":
10,
"title":
"Free Cams | Watch Webcam Sex... Filthy, Unfiltered and Free!",
"link":
"https://www.cam4.com/all",
"redirect_link":
"https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.cam4.com/all&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQFnoECC4QAQ",
"displayed_link":
"https://www.cam4.com › all",
"favicon":
"https://serpapi.com/searches/6892be506e22372dfb608490/images/de0fc1a4f680d6400c4e0a50efe8bf5bd2b0ea1da66aa4e6e92b4be9a889fd44.png",
"snippet":
"CAM4 is the ultimate destination to indulge in all things naughty and nice. We have a diverse selection of broadcasters from around the world who are beautiful ...",
"snippet_highlighted_words":
[
"CAM4 is the ultimate destination to indulge in all things naughty and nice"
],
"source":
"CAM4"
}
],
"pagination":
{
"current":
1,
"next":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=10&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8NMDegQIBxAW",
"other_pages":
{
"2":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=10&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAE",
"3":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=20&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAG",
"4":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=30&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAI",
"5":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=40&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAK",
"6":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=50&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAM",
"7":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=60&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAO",
"8":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=70&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAQ",
"9":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=80&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAS",
"10":
"https://www.google.com/search?q=ADULT+WEBCAM+CATEGORY&safe=off&sca_esv=38b8b35f2fe0540c&hl=en&gl=us&ei=Ur6SaJ8V5NDWxA-CxOyxDg&start=90&sa=N&sstk=Ac65TH5dCEDRwVVaspInO3usoS1rdsQrGqF0tD6rnwXHzD9vOkL0KBlUbvHoN24KX4NFIFqrTl_6RD1UREiTbFjEq-alpOZ5O2b37w&ved=2ahUKEwifhruEkvWOAxVkqJUCHQIiO-YQ8tMDegQIBxAU"
}
},
"serpapi_pagination":
{
"current":
1,
"next_link":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=10",
"next":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=10",
"other_pages":
{
"2":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=10",
"3":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=20",
"4":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=30",
"5":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=40",
"6":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=50",
"7":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=60",
"8":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=70",
"9":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=80",
"10":
"https://serpapi.com/search.json?device=desktop&engine=google&gl=us&google_domain=google.com&hl=en&location=United+States&q=ADULT+WEBCAM+CATEGORY&safe=off&start=90"
}
}
}