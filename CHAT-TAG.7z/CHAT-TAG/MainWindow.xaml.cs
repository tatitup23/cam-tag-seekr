using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WebcamTagScanner
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<TagResult> Results { get; set; } = new();

        public MainWindow()
        {
            InitializeComponent();
            ResultsGrid.ItemsSource = Results;
        }

        private async void Scan_Click(object sender, RoutedEventArgs e)
        {
            Results.Clear();
            string bingApiKey = ApiKeyBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(bingApiKey))
            {
                MessageBox.Show("Please enter your Bing Search API key.");
                return;
            }

            Scan_Click_DisableUI(true);
            try
            {
                // 1. Discover webcam sites via Bing
                var webcamSites = await BingSearchService.DiscoverWebcamSitesAsync(bingApiKey);

                // 2. For each known site, scrape tags/categories
                foreach (var site in webcamSites)
                {
                    var tags = await SiteScraperService.GetTagsForSiteAsync(site);
                    foreach (var tag in tags.Distinct())
                    {
                        Results.Add(new TagResult { Site = site, Tag = tag });
                    }
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                Scan_Click_DisableUI(false);
            }
        }

        void Scan_Click_DisableUI(bool disable)
        {
            ApiKeyBox.IsEnabled = !disable;
            ResultsGrid.IsEnabled = !disable;
        }
    }

    public class TagResult
    {
        public string Site { get; set; }
        public string Tag { get; set; }
    }
}